
import React from 'react';
import { Phone, Mail, MapPin, Clock, Star, Instagram, Facebook, MessageCircle } from 'lucide-react';
import { CLINIC_INFO } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer id="contact" className="bg-white pt-20 border-t border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 pb-16">
          <div className="col-span-1 lg:col-span-1">
             <div className="flex-shrink-0 flex flex-col mb-6">
                <span className="text-sky-700 font-serif text-2xl leading-none">Dr. Swati's</span>
                <span className="text-xs text-slate-500 uppercase tracking-widest font-bold">Multispeciality Dental Clinic</span>
            </div>
            <p className="text-slate-600 text-sm leading-relaxed mb-6">
              Expert dental care you can trust. Providing families in Bhopal with professional, comfortable, and affordable dental solutions.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-sky-600 hover:bg-sky-600 hover:text-white transition-all shadow-sm"><Instagram size={20} /></a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-sky-600 hover:bg-sky-600 hover:text-white transition-all shadow-sm"><Facebook size={20} /></a>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-slate-900 mb-6 uppercase text-sm tracking-widest">Our Services</h4>
            <ul className="space-y-4 text-slate-600 text-sm">
              <li><a href="#services" className="hover:text-sky-600 transition-colors">Root Canal (RCT)</a></li>
              <li><a href="#services" className="hover:text-sky-600 transition-colors">Pediatric Care</a></li>
              <li><a href="#services" className="hover:text-sky-600 transition-colors">Extractions</a></li>
              <li><a href="#services" className="hover:text-sky-600 transition-colors">Teeth Whitening</a></li>
              <li><a href="#services" className="hover:text-sky-600 transition-colors">General Checkups</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-slate-900 mb-6 uppercase text-sm tracking-widest">Contact Info</h4>
            <ul className="space-y-4 text-slate-600 text-sm">
              <li className="flex items-start gap-3">
                <Phone size={18} className="text-sky-600 flex-shrink-0" />
                <span>{CLINIC_INFO.phone}</span>
              </li>
              <li className="flex items-start gap-3">
                <MessageCircle size={18} className="text-emerald-600 flex-shrink-0" />
                <a href={CLINIC_INFO.whatsappUrl} className="hover:text-emerald-600 transition-colors">Chat on WhatsApp</a>
              </li>
              <li className="flex items-start gap-3">
                <MapPin size={18} className="text-sky-600 flex-shrink-0" />
                <span>{CLINIC_INFO.address}</span>
              </li>
              <li className="flex items-start gap-3">
                <Clock size={18} className="text-sky-600 flex-shrink-0" />
                <span>{CLINIC_INFO.timings}</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-slate-900 mb-6 uppercase text-sm tracking-widest">Trust & Quality</h4>
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
               <div className="flex items-center gap-1 mb-2">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={14} className="fill-amber-400 text-amber-400" />
                ))}
              </div>
              <p className="font-bold text-slate-900 text-sm mb-1">5.0 Star Rating</p>
              <p className="text-xs text-slate-500">Based on 52 genuine patient reviews in Bhopal.</p>
              <a 
                href={CLINIC_INFO.googleMapsUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                className="block mt-4 text-xs font-bold text-sky-600 hover:underline"
              >
                View on Google Maps
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-100 py-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} {CLINIC_INFO.name}. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-sky-600">Privacy Policy</a>
            <a href="#" className="hover:text-sky-600">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
