
import React from 'react';
import { CLINIC_INFO, TRUST_SIGNALS } from '../constants';

const About: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          <div className="flex-1 order-2 lg:order-1">
            <div className="grid grid-cols-2 gap-4">
              {TRUST_SIGNALS.map((signal, idx) => (
                <div key={idx} className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
                  <div className="mb-4">{signal.icon}</div>
                  <h4 className="font-bold text-slate-900 mb-1">{signal.title}</h4>
                  <p className="text-xs text-slate-500">{signal.desc}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="flex-1 order-1 lg:order-2">
            <h2 className="text-sm font-bold text-sky-600 uppercase tracking-widest mb-3">Meet Your Dentist</h2>
            <h3 className="text-3xl md:text-4xl font-serif text-slate-900 mb-6">Expert Care by {CLINIC_INFO.doctor}</h3>
            <p className="text-slate-600 mb-6 leading-relaxed">
              Dr. Swati is a highly recommended dental professional in Bhopal, known for her kindness and precision. Her approach to dentistry is patient-first, ensuring that every procedure—from a simple cleaning to a complex Root Canal—is handled with the utmost care.
            </p>
            <p className="text-slate-600 mb-8 leading-relaxed">
              Our clinic, <strong>{CLINIC_INFO.hindiName}</strong>, is a multispeciality facility designed to provide affordable yet high-quality dental treatments. Being a women-owned clinic, we take pride in our gentle approach, making us the top choice for children and anxious patients.
            </p>
            
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0 mt-1">
                  <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                </div>
                <p className="text-slate-700 font-medium">Trusted by over 500+ local families</p>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0 mt-1">
                  <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                </div>
                <p className="text-slate-700 font-medium">Advanced pain-free RCT specialist</p>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0 mt-1">
                  <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                </div>
                <p className="text-slate-700 font-medium">Child-friendly environment & techniques</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
