
import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import About from './components/About';
import Testimonials from './components/Testimonials';
import BookingForm from './components/BookingForm';
import Footer from './components/Footer';
import { CLINIC_INFO } from './constants';
import { Phone, Calendar, MessageCircle } from 'lucide-react';

const App: React.FC = () => {
  // Encoded address for the map iframe
  const encodedSearch = encodeURIComponent("Dr. Swati's Multispeciality Dental Clinic Amrai Housing Board Colony Bhopal");
  const fallbackMapUrl = `https://maps.google.com/maps?q=${encodedSearch}&t=&z=15&ie=UTF8&iwloc=&output=embed`;

  return (
    <div className="min-h-screen relative">
      <Navbar />
      
      <main>
        <Hero />
        
        {/* Simple divider section for trust */}
        <section className="bg-white border-y border-slate-100 py-12">
           <div className="max-w-7xl mx-auto px-4 flex flex-wrap justify-center gap-12 md:gap-24 opacity-60 grayscale hover:grayscale-0 transition-all">
             <div className="flex items-center gap-2 font-bold text-slate-400">
               <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-600">5.0</div>
               Patient Satisfaction
             </div>
             <div className="flex items-center gap-2 font-bold text-slate-400">
               <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-600">★</div>
               Top Rated Bhopal
             </div>
             <div className="flex items-center gap-2 font-bold text-slate-400">
               <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-600">🦷</div>
               Multispeciality Care
             </div>
           </div>
        </section>

        <Services />
        <About />
        <Testimonials />

        {/* Booking Section */}
        <section className="py-24 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1/2 bg-sky-900 -z-10"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col lg:flex-row gap-16 items-start">
              <div className="flex-1 text-white lg:pt-12">
                <h2 className="text-3xl md:text-5xl font-serif mb-6 leading-tight">Your Journey to a Perfect Smile Starts Here</h2>
                <p className="text-sky-100 text-lg mb-8">
                  Book an appointment today and experience the difference of patient-centric care at {CLINIC_INFO.name}. 
                </p>
                <div className="space-y-6">
                  <div className="flex gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center flex-shrink-0">
                      <Phone size={24} className="text-sky-300" />
                    </div>
                    <div>
                      <h4 className="font-bold text-white">Call for Queries</h4>
                      <p className="text-sky-200">{CLINIC_INFO.phone}</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center flex-shrink-0">
                      <MessageCircle size={24} className="text-emerald-400" />
                    </div>
                    <div>
                      <h4 className="font-bold text-white">WhatsApp</h4>
                      <a href={CLINIC_INFO.whatsappUrl} className="text-sky-200 hover:text-white transition-colors">Chat Now</a>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex-1 w-full max-w-xl mx-auto lg:mx-0">
                <BookingForm />
              </div>
            </div>
          </div>
        </section>

        {/* Location Section */}
        <section className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row gap-12 bg-slate-50 rounded-[2.5rem] overflow-hidden border border-slate-100 p-4 md:p-8">
              <div className="flex-1">
                <iframe 
                  src={fallbackMapUrl} 
                  className="w-full h-[400px] md:h-full min-h-[400px] border-0 rounded-3xl"
                  loading="lazy"
                  title="Clinic Location Map"
                ></iframe>
              </div>
              <div className="flex-1 p-8 md:p-12">
                <h3 className="text-2xl font-bold mb-6">Our Location in Bhopal</h3>
                <p className="text-slate-600 mb-8">{CLINIC_INFO.address}</p>
                <div className="space-y-4">
                  <div className="flex justify-between items-center py-3 border-b border-slate-200">
                    <span className="font-semibold text-slate-700">Category</span>
                    <span className="text-slate-500">Multispeciality Dental Clinic</span>
                  </div>
                  <div className="flex justify-between items-center py-3 border-b border-slate-200">
                    <span className="font-semibold text-slate-700">Rating</span>
                    <span className="text-emerald-600 font-bold flex items-center gap-1">5.0 ★ (52 Reviews)</span>
                  </div>
                  <div className="flex justify-between items-center py-3">
                    <span className="font-semibold text-slate-700">Ownership</span>
                    <span className="text-slate-500">Women-Owned Clinic</span>
                  </div>
                </div>
                <a 
                  href={CLINIC_INFO.googleMapsUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="mt-10 block w-full text-center py-4 bg-white border-2 border-slate-200 text-slate-700 rounded-xl font-bold hover:bg-slate-50 transition-all"
                >
                  Open in Google Maps
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />

      {/* Floating Action Buttons */}
      <div className="fixed bottom-6 left-6 z-50 flex flex-col gap-4 md:hidden">
        <a 
          href={CLINIC_INFO.whatsappUrl} 
          target="_blank"
          rel="noopener noreferrer"
          className="w-14 h-14 bg-emerald-500 text-white rounded-full shadow-2xl flex items-center justify-center hover:scale-110 transition-all"
          title="Chat on WhatsApp"
        >
          <MessageCircle size={28} />
        </a>
        <a 
          href={`tel:${CLINIC_INFO.phone}`} 
          className="w-14 h-14 bg-sky-600 text-white rounded-full shadow-2xl flex items-center justify-center animate-pulse"
          title="Call Us"
        >
          <Phone size={24} />
        </a>
      </div>

      {/* Desktop WhatsApp Button */}
      <div className="hidden md:block fixed bottom-24 right-6 z-50">
        <a 
          href={CLINIC_INFO.whatsappUrl} 
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-3 bg-white border border-slate-100 text-slate-700 px-4 py-2 rounded-full shadow-xl hover:shadow-emerald-500/10 hover:border-emerald-200 transition-all group"
        >
          <div className="w-8 h-8 bg-emerald-500 text-white rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
            <MessageCircle size={18} />
          </div>
          <span className="text-sm font-bold pr-2">Chat with Dr. Swati</span>
        </a>
      </div>
    </div>
  );
};

export default App;
