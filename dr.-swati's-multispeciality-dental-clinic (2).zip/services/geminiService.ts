
import { GoogleGenAI } from "@google/genai";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async getDentalAdvice(query: string): Promise<string> {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: query,
        config: {
          systemInstruction: `You are a helpful AI assistant for Dr. Swati's Multispeciality Dental Clinic in Bhopal. 
          Your goal is to provide general dental wellness advice, explain common procedures (like RCT, extraction, pediatric care), 
          and encourage users to book an appointment with Dr. Swati for a professional diagnosis. 
          Always mention that Dr. Swati is known for her gentle approach and pain-free treatments. 
          Keep responses concise, warm, and professional. 
          Important: Do not give medical prescriptions. Always advise a physical checkup.`,
          temperature: 0.7,
        },
      });

      return response.text || "I'm sorry, I couldn't process that. Please contact the clinic directly at +91 79994 37377 for assistance.";
    } catch (error) {
      console.error("Gemini API Error:", error);
      return "Hello! I'm currently having a small technical hiccup. Please call Dr. Swati's clinic directly for expert dental advice!";
    }
  }
}

export const geminiService = new GeminiService();
