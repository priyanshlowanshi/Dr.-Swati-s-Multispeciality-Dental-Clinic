
export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
}

export interface Review {
  id: number;
  author: string;
  rating: number;
  text: string;
  date: string;
}

export interface BookingFormData {
  name: string;
  phone: string;
  service: string;
  date: string;
  message: string;
}
