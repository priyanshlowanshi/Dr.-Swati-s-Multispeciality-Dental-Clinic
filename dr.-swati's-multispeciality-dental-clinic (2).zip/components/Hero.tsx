
import React from 'react';
import { Star, MapPin, Calendar, Phone } from 'lucide-react';
import { CLINIC_INFO } from '../constants';

const Hero: React.FC = () => {
  return (
    <section id="home" className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden">
      {/* Background blobs for aesthetic */}
      <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/3 w-[500px] h-[500px] bg-sky-100/50 rounded-full blur-3xl -z-10"></div>
      <div className="absolute bottom-0 left-0 translate-y-1/2 -translate-x-1/3 w-[400px] h-[400px] bg-emerald-50/50 rounded-full blur-3xl -z-10"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <div className="flex-1 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full shadow-sm border border-slate-100 mb-6 animate-fade-in">
              <div className="flex gap-0.5">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={16} className="fill-amber-400 text-amber-400" />
                ))}
              </div>
              <span className="text-sm font-semibold text-slate-700">5.0 Rating (52 Reviews)</span>
            </div>

            <h1 className="text-4xl md:text-6xl font-serif text-slate-900 leading-tight mb-6">
              Gentle, Expert & <span className="text-sky-600 italic">Comfortable</span> Dental Care in Bhopal
            </h1>
            
            <p className="text-lg md:text-xl text-slate-600 mb-10 max-w-2xl mx-auto lg:mx-0">
              Transforming smiles with a kind heart and precise hands. {CLINIC_INFO.name} specializes in painless treatments for families and children.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <a
                href="#booking"
                className="px-8 py-4 bg-sky-600 text-white rounded-full font-bold text-lg hover:bg-sky-700 hover:shadow-lg transition-all flex items-center justify-center gap-2"
              >
                <Calendar size={20} />
                Book Appointment
              </a>
              <a
                href={CLINIC_INFO.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-8 py-4 bg-white text-slate-700 border border-slate-200 rounded-full font-bold text-lg hover:bg-slate-50 transition-all flex items-center justify-center gap-2"
              >
                <MapPin size={20} className="text-sky-600" />
                Get Directions
              </a>
            </div>

            <div className="mt-8 flex flex-wrap justify-center lg:justify-start gap-8 text-sm text-slate-500 font-medium">
              <span className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-emerald-500"></div> Women-Owned</span>
              <span className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-emerald-500"></div> Child-Friendly</span>
              <span className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-emerald-500"></div> Affordable Rates</span>
            </div>
          </div>

          <div className="flex-1 relative">
            <div className="relative w-full aspect-square rounded-[2rem] overflow-hidden shadow-2xl">
               <img 
                src="https://picsum.photos/seed/dentist-visit/800/800" 
                alt="Dental Clinic Interior" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
              <div className="absolute bottom-6 left-6 right-6 p-6 bg-white/90 backdrop-blur rounded-2xl shadow-lg border border-white/20">
                <p className="text-sky-800 font-bold mb-1">Dr. Swati (BDS)</p>
                <p className="text-slate-600 text-sm leading-relaxed">"Every patient deserves a painless and comfortable dental experience. We treat your family like our own."</p>
              </div>
            </div>
            
            {/* Floating badge */}
            <div className="absolute -top-6 -right-6 bg-emerald-600 text-white p-6 rounded-2xl shadow-xl animate-bounce-slow">
              <p className="text-3xl font-bold">5.0</p>
              <p className="text-xs uppercase tracking-tighter opacity-80">Google Rating</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
