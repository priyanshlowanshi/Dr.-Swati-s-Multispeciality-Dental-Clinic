
import React from 'react';
import { Star, Quote } from 'lucide-react';
import { REVIEWS } from '../constants';

const Testimonials: React.FC = () => {
  return (
    <section id="reviews" className="py-24 bg-sky-900 text-white overflow-hidden relative">
      {/* Decorative background elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-sky-800 rounded-full blur-3xl -z-0 -translate-y-1/2"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-sky-800 rounded-full mb-6">
            <Star className="fill-amber-400 text-amber-400" size={16} />
            <span className="text-sm font-bold">5.0 / 5.0 Google Reviews</span>
          </div>
          <h2 className="text-3xl md:text-5xl font-serif mb-6">What Our Patients Say</h2>
          <p className="text-sky-200 max-w-2xl mx-auto">
            Real feedback from our wonderful patients in Bhopal who trust Dr. Swati for their family dental health.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {REVIEWS.map((review) => (
            <div key={review.id} className="bg-sky-800/50 backdrop-blur-sm p-8 rounded-3xl border border-sky-700 flex flex-col h-full">
              <div className="flex gap-1 mb-6">
                {[...Array(review.rating)].map((_, i) => (
                  <Star key={i} size={16} className="fill-amber-400 text-amber-400" />
                ))}
              </div>
              <p className="text-lg italic text-sky-100 mb-8 flex-grow">"{review.text}"</p>
              <div className="flex items-center gap-4 border-t border-sky-700 pt-6">
                <div className="w-12 h-12 rounded-full bg-sky-700 flex items-center justify-center font-bold text-sky-300">
                  {review.author.charAt(0)}
                </div>
                <div>
                  <h4 className="font-bold">{review.author}</h4>
                  <p className="text-xs text-sky-400">{review.date}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <a 
            href="https://www.google.com/maps/search/?api=1&query=Dr.+Swati%27s+Multispeciality+Dental+Clinic+Bhopal" 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 font-semibold text-sky-200 hover:text-white transition-all"
          >
            Read more reviews on Google &rarr;
          </a>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
