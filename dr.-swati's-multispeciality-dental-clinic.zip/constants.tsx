
import React from 'react';
import { ShieldCheck, UserCheck, Heart, Sparkles, Baby, PhoneCall } from 'lucide-react';
import { Service, Review } from './types';

export const CLINIC_INFO = {
  name: "Dr. Swati's Multispeciality Dental Clinic",
  hindiName: "दर. स्वती'स मल्टीस्पेशलिटी डेंटल क्लिनिक",
  phone: "+91 79994 37377",
  whatsapp: "+91 79994 37377",
  whatsappUrl: "https://wa.me/917999437377?text=Hello%20Dr.%20Swati's%20Clinic,%20I'd%20like%20to%20enquire%20about%20dental%20services.",
  address: "Sr. LIG - 44, Amravati South Main Road, Amrai Housing Board Colony, Bagh Swaniya, Bhopal, Madhya Pradesh 462043",
  googleMapsUrl: "https://www.google.com/maps?q=Dr.+Swati's+Multispeciality+Dental+Clinic+Bhopal",
  rating: 5.0,
  reviewCount: 52,
  timings: "Mon-Sat: 09:30 AM - 08:30 PM",
  doctor: "Dr. Swati"
};

export const SERVICES: Service[] = [
  {
    id: 'rct',
    title: 'Root Canal Treatment (RCT)',
    description: 'Expertly performed pain-free root canals to save your natural teeth with precision.',
    icon: '🦷'
  },
  {
    id: 'pediatric',
    title: 'Pediatric Dentistry',
    description: 'Gentle and child-friendly dental care to ensure your little ones have healthy smiles.',
    icon: '👶'
  },
  {
    id: 'extraction',
    title: 'Tooth Extraction',
    description: 'Safe and comfortable tooth removal procedures using advanced techniques.',
    icon: '✨'
  },
  {
    id: 'general',
    title: 'General Dentistry',
    description: 'Comprehensive preventive care, scaling, and polishing for the whole family.',
    icon: '🏥'
  },
  {
    id: 'preventive',
    title: 'Preventive Checkups',
    description: 'Early detection and management of dental issues to maintain lifelong oral health.',
    icon: '🛡️'
  }
];

export const REVIEWS: Review[] = [
  {
    id: 1,
    author: "Amit Sharma",
    rating: 5,
    text: "Dr. Swati is very kind and professional. The treatment was painless and affordable. Highly recommended for family dentistry.",
    date: "2 months ago"
  },
  {
    id: 2,
    author: "Priya Singh",
    rating: 5,
    text: "Best dentist in Bhopal for kids. My daughter was very comfortable during her first checkup. Very gentle approach.",
    date: "1 month ago"
  },
  {
    id: 3,
    author: "Rahul Verma",
    rating: 5,
    text: "Extremely satisfied with the RCT. Precise work and very nominal charges compared to other multispeciality clinics.",
    date: "3 weeks ago"
  }
];

export const TRUST_SIGNALS = [
  {
    title: "5.0 Star Rating",
    desc: "Perfect score from 50+ happy patients",
    icon: <ShieldCheck className="w-6 h-6 text-emerald-500" />
  },
  {
    title: "Child Friendly",
    desc: "Special focus on pediatric comfort",
    icon: <Baby className="w-6 h-6 text-sky-500" />
  },
  {
    title: "Women Owned",
    desc: "Trusted female leadership & empathy",
    icon: <Heart className="w-6 h-6 text-rose-500" />
  },
  {
    title: "Affordable Care",
    desc: "Premium quality at nominal rates",
    icon: <Sparkles className="w-6 h-6 text-amber-500" />
  }
];
