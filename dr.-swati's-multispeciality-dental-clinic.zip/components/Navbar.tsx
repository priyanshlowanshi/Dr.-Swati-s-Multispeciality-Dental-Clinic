
import React, { useState, useEffect } from 'react';
import { Menu, X, Phone } from 'lucide-react';
import { CLINIC_INFO } from '../constants';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'Services', href: '#services' },
    { name: 'About Dr. Swati', href: '#about' },
    { name: 'Reviews', href: '#reviews' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${scrolled ? 'bg-white/90 backdrop-blur-md shadow-sm py-3' : 'bg-transparent py-5'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <div className="flex-shrink-0 flex flex-col">
            <span className="text-sky-700 font-serif text-xl md:text-2xl leading-none">Dr. Swati's</span>
            <span className="text-[10px] md:text-xs text-slate-500 uppercase tracking-widest font-bold">Multispeciality Dental Clinic</span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-slate-600 hover:text-sky-600 font-medium transition-colors"
              >
                {link.name}
              </a>
            ))}
            <a
              href={`tel:${CLINIC_INFO.phone}`}
              className="bg-sky-600 text-white px-5 py-2 rounded-full font-semibold hover:bg-sky-700 transition-all flex items-center gap-2"
            >
              <Phone size={18} />
              {CLINIC_INFO.phone}
            </a>
          </div>

          {/* Mobile Menu Toggle */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-slate-600 p-2 focus:outline-none"
            >
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      <div className={`md:hidden absolute w-full bg-white shadow-xl transition-all duration-300 ease-in-out ${isOpen ? 'max-h-screen opacity-100 py-6' : 'max-h-0 opacity-0 overflow-hidden'}`}>
        <div className="flex flex-col items-center space-y-4 px-4">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              onClick={() => setIsOpen(false)}
              className="text-lg text-slate-600 font-medium hover:text-sky-600"
            >
              {link.name}
            </a>
          ))}
          <a
            href={`tel:${CLINIC_INFO.phone}`}
            className="w-full text-center bg-sky-600 text-white py-3 rounded-lg font-semibold flex items-center justify-center gap-2"
          >
            <Phone size={20} />
            Call Now
          </a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
