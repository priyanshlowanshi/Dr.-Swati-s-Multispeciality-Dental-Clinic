
import React, { useState } from 'react';
import { Send, CheckCircle } from 'lucide-react';
import { SERVICES } from '../constants';

const BookingForm: React.FC = () => {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      setIsSubmitted(true);
    }, 1500);
  };

  if (isSubmitted) {
    return (
      <div className="bg-emerald-50 border border-emerald-100 p-8 rounded-3xl text-center">
        <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <CheckCircle size={32} />
        </div>
        <h3 className="text-2xl font-bold text-emerald-900 mb-2">Booking Requested!</h3>
        <p className="text-emerald-700 mb-6">Thank you for choosing Dr. Swati's clinic. We will call you shortly to confirm your slot.</p>
        <button 
          onClick={() => setIsSubmitted(false)}
          className="text-emerald-700 font-semibold underline underline-offset-4"
        >
          Book another appointment
        </button>
      </div>
    );
  }

  return (
    <div id="booking" className="bg-white p-8 md:p-12 rounded-3xl shadow-2xl shadow-sky-900/10 border border-slate-100">
      <h3 className="text-2xl font-bold text-slate-900 mb-2">Book Your Visit</h3>
      <p className="text-slate-500 mb-8">Schedule a consultation with Dr. Swati at your convenience.</p>
      
      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Your Name</label>
            <input 
              type="text" 
              required
              placeholder="Full Name"
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-all outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Phone Number</label>
            <input 
              type="tel" 
              required
              placeholder="+91 00000 00000"
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-all outline-none"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">Select Service</label>
          <select className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-all outline-none">
            {SERVICES.map(s => <option key={s.id} value={s.id}>{s.title}</option>)}
          </select>
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">Preferred Date</label>
          <input 
            type="date" 
            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-all outline-none"
          />
        </div>

        <button 
          disabled={isLoading}
          type="submit"
          className="w-full py-4 bg-sky-600 text-white rounded-xl font-bold text-lg hover:bg-sky-700 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {isLoading ? (
            <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
          ) : (
            <>
              <Send size={18} />
              Submit Request
            </>
          )}
        </button>
      </form>
      
      <p className="mt-6 text-xs text-center text-slate-400">
        By submitting, you agree to receive a callback for appointment confirmation.
      </p>
    </div>
  );
};

export default BookingForm;
